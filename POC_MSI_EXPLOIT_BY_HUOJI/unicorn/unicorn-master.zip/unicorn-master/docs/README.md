Documention of Unicorn engine.

* How to compile & install Unicorn.

	http://unicorn-engine.org/docs/

* Tutorial on programming with C & Python languages.

	http://unicorn-engine.org/docs/tutorial.html

* Compare Unicorn & QEMU

	http://unicorn-engine.org/docs/beyond_qemu.html

* Micro Uncorn-Engine API Documentation in Chinese

	https://github.com/kabeor/Micro-Unicorn-Engine-API-Documentation
