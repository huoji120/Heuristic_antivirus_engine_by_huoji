#ifndef HW_M68K_H
#define HW_M68K_H

#include "uc_priv.h"

void dummy_m68k_machine_init(struct uc_struct *uc);

void m68k_cpu_register_types(void *opaque);

#endif
